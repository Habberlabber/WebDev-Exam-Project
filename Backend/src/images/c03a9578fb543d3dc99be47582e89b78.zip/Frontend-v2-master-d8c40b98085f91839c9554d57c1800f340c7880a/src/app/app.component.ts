import { Component } from '@angular/core';
import {IMyDrpOptions} from 'mydaterangepicker';

declare var UIkit: any;

@Component({
  selector: 'afbud-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

export class AppComponent {
  title = 'afbud';

  // myDateRangePickerOptions: IMyDrpOptions = {
  //   dateFormat: 'dd.mm.yyyy',
  //   openSelectorOnInputClick: true,
  //   editableDateRangeField: false,
  //   showClearBtn: false,
  //   showApplyBtn: false,
  //   showClearDateRangeBtn: false,
  //   showSelectorArrow: false,
  //   showSelectDateText: false,
  //   yearSelector: false,
  //   dayLabels: {su: 'Søn', mo: 'Man', tu: 'Tir', we: 'Ons', th: 'Tor', fr: 'Fre', sa: 'Lør'},
  //   monthLabels: { 1: 'Jan', 2: 'Feb', 3: 'Mar', 4: 'Apr', 5: 'Maj', 6: 'Jun', 7: 'Jul', 8: 'Aug', 9: 'Sep', 10: 'Okt', 11: 'Nov', 12: 'Dec' }
  // };

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'afbud-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.scss']
})
export class CardComponent {
  
  // Boolena flag for expanded state
  expanded:boolean; 
  // function to toggle the expanded state of the card
  toggleExpand(){
    this.expanded = !this.expanded;
  }

}

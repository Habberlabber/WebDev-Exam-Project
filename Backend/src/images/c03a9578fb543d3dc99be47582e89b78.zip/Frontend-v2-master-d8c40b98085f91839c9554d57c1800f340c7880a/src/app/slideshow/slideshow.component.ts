import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'afbud-slideshow',
  templateUrl: './slideshow.component.html',
  styleUrls: ['./slideshow.component.scss']
})
export class SlideshowComponent implements OnInit {

  curImgIndex:number = 0;

  constructor() { }

  ngOnInit() {
    this.slideArray[this.curImgIndex].class = 'visible';
  }

  prevImage(){
    if(this.curImgIndex > 0){
      this.slideArray[this.curImgIndex--].class = 'slideOutLeft';
      this.slideArray[this.curImgIndex].class = 'slideInLeft';
    }
  }

  nextImage(){
    if(this.curImgIndex < this.slideArray.length-1){
      this.slideArray[this.curImgIndex++].class = 'slideOutRight';
      this.slideArray[this.curImgIndex].class = 'slideInRight';
    }
  }

  slideArray = [
    {
      url: "https://www.imagesource.com/Doc/IS0/Media/CMS3/f/a/b/1/IS098U8XV.jpg",
      class: ""
    },
    {
      url: "https://images.pexels.com/photos/208701/pexels-photo-208701.jpeg?w=1260&h=750&dpr=2&auto=compress&cs=tinysrgb",
      class: ""
    },
    {
      url: "https://images.pexels.com/photos/458555/pexels-photo-458555.jpeg?w=1260&h=750&dpr=2&auto=compress&cs=tinysrgb",
      class: ""
    }
  ]

}

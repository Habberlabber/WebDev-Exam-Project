import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'afbud-hotel-stars',
  templateUrl: './hotel-stars.component.html',
  styleUrls: ['./hotel-stars.component.scss']
})
export class HotelStarsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
